package pt.ulusofona.aed.deisiworldmeter;

public class Result {
    boolean success;
    String error;
    String result;

    public Result() {
    }
}