package pt.ulusofona.aed.deisiworldmeter;
public class PopulationIncrease {


    Pais pais;
    int[] intervalo;

    public PopulationIncrease(Pais pais, int[] intervalo) {
        this.pais = pais;
        this.intervalo = intervalo;
    }
}
