package pt.ulusofona.aed.deisiworldmeter;

import pt.ulusofona.aed.deisiworldmeter.Cidade;
import pt.ulusofona.aed.deisiworldmeter.Pais;
import pt.ulusofona.aed.deisiworldmeter.Populacao;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;





public class Main {

    static ArrayList<Pais> paises = new ArrayList<Pais>();

    static ArrayList<Populacao> populacaoArray = new ArrayList<Populacao>();

    static ArrayList<Cidade> cidades = new ArrayList<Cidade>();

    public static boolean parseFiles(File folder) {

        Scanner scanner = null;


            File filePaises= new File(folder,"paises.csv");

            File filePopulacao= new File(folder,"populacao.csv");

            File fileCidades= new File(folder,"cidades.csv");

            try{
                scanner = new Scanner(filePaises);


            }catch(FileNotFoundException e){
                return false;
            }


            //ler ficheiro paises
             while(scanner.hasNext()){
                 String linha = scanner.nextLine();
                 String[] partes =linha.split(",");
                 Pais pais = new Pais(Integer.parseInt(partes[0]), partes[1], partes[2], partes[3]);
                 paises.add(pais);
             }
        try{
            scanner = new Scanner(filePopulacao);


        }catch(FileNotFoundException e){
            return false;
        }
            while(scanner.hasNext()){
                String linha = scanner.nextLine();
                String[] partes =linha.split(",");
                Populacao populacao = new Populacao(Integer.parseInt(partes[0]), Integer.parseInt(partes[1]), Integer.parseInt(partes[2]), Integer.parseInt(partes[3]), Float.parseFloat(partes[4]));
                 populacaoArray.add(populacao);
            }
        try{
            scanner = new Scanner(fileCidades);


        }catch(FileNotFoundException e){
            return false;
        }
            while(scanner.hasNext()){
                String linha = scanner.nextLine();
                String[] partes =linha.split(",");
                Cidade cidade = new Cidade(partes[0], partes[1], Integer.parseInt(partes[2]), Float.parseFloat(partes[3]), Float.parseFloat(partes[4]), Float.parseFloat(partes[5]));
                cidades.add(cidade);
            }


        return true;
    }

    public static ArrayList getObjects(TipoEntidade macaco){






        ArrayList receba = new ArrayList() ;





        return receba;
    }

    public static void main(String[] args) {
        System.out.println("Hello world!");

        long start = System.currentTimeMillis();
        boolean parseok = parseFiles(new File("Testfiles"));
        if(!parseok){
            System.out.println("nigger");
            return;
        }
        long end = System.currentTimeMillis();
        System.out.println("FIXE "+(end-start)+"ms");










    }




}